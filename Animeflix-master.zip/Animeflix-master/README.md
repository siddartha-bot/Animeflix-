

https://user-images.githubusercontent.com/69306837/203926852-d5343dc8-805b-4103-8f05-d2fa29ec8c47.mp4



<img src="https://github.com/tekumalsaisaketh/Animeflix/blob/master/public/0.png" width=30% height=30%>
<img src="https://github.com/tekumalsaisaketh/Animeflix/blob/master/public/1.png" width=30% height=30%>
<img src="https://github.com/tekumalsaisaketh/Animeflix/blob/master/public/2.png" width=30% height=30%>
<img src="https://github.com/tekumalsaisaketh/Animeflix/blob/master/public/3.png" width=30% height=30%>
<img src="https://github.com/tekumalsaisaketh/Animeflix/blob/master/public/4.png" width=30% height=30%>
